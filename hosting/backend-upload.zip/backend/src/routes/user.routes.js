import express from "express";
import { protect, sameUser, requireRole } from "../middlewares/auth.middleware.js";
import {
  getAccountDashboard,
  getProfile,
  updateProfile,
  applyForPremium,
  getWishlist,
  addToWishlist,
  removeFromWishlist,
  getAdminCustomers,
  getOneUserAdmin,
  createUserAdmin,
  updateUserAdmin,
  deleteUserAdmin,
} from "../controller/user.controller.js";

const router = express.Router();

router.use(protect);

router.get("/admin/list", requireRole(["admin"]), getAdminCustomers);
router.get("/admin/:userId", requireRole(["admin"]), getOneUserAdmin);
router.post("/admin", requireRole(["admin"]), createUserAdmin);
router.put("/admin/:userId", requireRole(["admin"]), updateUserAdmin);
router.delete("/admin/:userId", requireRole(["admin"]), deleteUserAdmin);

router.get("/:userId/dashboard", sameUser, getAccountDashboard);
router.get("/:userId", sameUser, getProfile);
router.put("/:userId", sameUser, updateProfile);
router.post("/:userId/apply-premium", sameUser, applyForPremium);
router.get("/:userId/wishlist", sameUser, getWishlist);
router.post("/:userId/wishlist/:productId", sameUser, addToWishlist);
router.delete("/:userId/wishlist/:productId", sameUser, removeFromWishlist);

export default router;
